# Differential Gaussian Rasterization used for compression
